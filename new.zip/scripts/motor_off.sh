sudo gpio write 29 0
