#/bin/bash

sleep 5
#cd /home/pi/firmware/azura-firmware/fcgi/
cd /home/pi/firmware/azura-firmware/new/bin/
sudo spawn-fcgi -n main_fcgi -p 8000
