sudo poweroff
