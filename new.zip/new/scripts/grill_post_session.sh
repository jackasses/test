#!/bin/bash

sudo python grill_post_session.py $1 $2 $3 $4 $5
echo "script done"
