#!/bin/bash

path="../data/"
file="wlan_ip"

path=$path$file

#sudo ifdown wlan0
#sudo ifup wlan0

VALUE=$(ip a | grep "inet" | grep -v "inet6" | grep -v "eth" | grep -v "host lo" | awk '{print $2}')
echo ${VALUE%/*}
#>/home/pi/wlan_ip
>$path
sudo sh -c "echo -n '${VALUE%/*}' >> $path"

