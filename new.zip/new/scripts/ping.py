import os
import sys
hostname = "google.com" #example
#hostname = "asdfrtmg.com" #example

def ping():
	response = os.system("ping -c 1 " + hostname)

	#and then check the response...
	if response == 0:
	  #print hostname, 'is up!'
	  sys.exit(0)
	else:
	  #print hostname, 'is down!'
	  sys.exit(1)

ping()