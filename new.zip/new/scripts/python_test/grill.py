import requests
import json
import sys
import getopt
import random
import oauth2 as urllib
from time import *

#1 session_ID
#2 operation mode
#3 lift_level
#4 power mode
#5 batterie level
#6 connection
#7 status
#8 error
#9 target temperature
#10  #11 #12 #13 temperatur
#14 fan
print 'Number of arguments:', len(sys.argv), 'arguments.'
print 'Argument List:', str(sys.argv)

def main(): 

  rand =  random.randint(1,600)
  print rand	
  url_data = 'https://staging-api.willhelmgrill.com/api/sessions/'+ str(sys.argv[1]) +'/data-points'

  print url_data

  fobj_in = open("/home/pi/access_token","r").readlines()

  if (len(fobj_in[0])>0):
    access_token = str(fobj_in[0])
    bearer = "Bearer " + access_token
    print "                           "
    bearer = bearer.replace("\n","")
    #  print bearer
    headers_in = {'accept': 'application/json','content-type': 'application/json', 'Authorization':bearer}
    print headers_in
    #   data_point = 0

    data_point = {
      "operation_mode": sys.argv[2],
      "lift_level":  int(sys.argv[3]),
      "power_mode": sys.argv[4],
      "batterie_level":  int(sys.argv[5]),
      "connection":  sys.argv[6],
      "status":  int(sys.argv[7]),
      "error":  int(sys.argv[8]),
      "target_temperature":  int(sys.argv[9]),
      "temperatures": [
         int(sys.argv[10]),
         int(sys.argv[11]),
         int(sys.argv[12]),
#	 int(rand),
         int(sys.argv[13]),     
#	 int(rand),
	 int(sys.argv[14])
#	 int(rand)
      ],
      "fans": [
         int(sys.argv[15]),
	 int(sys.argv[15])
      ]
    }

    data_point_body = json.dumps(data_point)
    print " "
    print data_point_body

    r = requests.post(
    url_data,
    headers=headers_in,
    data=data_point_body
    )

    print " "
    print r
    print "             "
    print r.text
    print "data posting"
    print "             "
    fobj_out = open("/home/pi/data_information","w")

    if str(r) in '<Response [401]>':
    	fobj_out.write(" ");
    else:
      print "load text"
      test = json.loads(r.text)
      print str(test['_id'])
      fobj_out.write(str(test['_id']))
    
    fobj_out.close()

  else:
    fobj_out = open("/home/pi/data_information","w")
    fobj_out.write("ERROR")
    fobj_out.close()

if __name__ == "__main__":
  try:
    main()
  except:
    print "Error main"
    sys.exit(1)


