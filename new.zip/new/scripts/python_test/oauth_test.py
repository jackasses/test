import oauth2 as oauth
import time
import urllib2 as urllib

echo_base_url = 'http://pilot.echo360.com/ess/scheduleapi/v1'

consumer = oauth.Consumer(key ='xxxxx', secret='xxxx')
client = oauth.Client(consumer)
params = "<person><first-name>Jon</first-name><last-name>Doe</last-name><title>Super  Hero</title><email-address>jdoe17@echo360.com</email-address><block-alerts>false</block-alerts><time-zone>US/Eastern</time-zone><locale>en_US</locale><credentials><user-name>jdoe17@echo360.com</user-name><password>password</password></credentials><organization-roles><organization-role><organization-id>b1973c39-dc76-4cab-a4aa-3f9efd628df2</organization-id><role>role-name-admin</role></organization-role></organization-roles></person>"

resp, content = client.request(
                echo_base_url + "/people/",
                method = "PUT",
                body=params,
                headers={'Content-type': 'application/xml'}
                #force_auth_header=True
                )
print resp, content
