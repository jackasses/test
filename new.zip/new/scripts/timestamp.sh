#!/bin/bash

sudo python /home/pi/firmware/azura-firmware/new/scripts/timestamp.py $1
