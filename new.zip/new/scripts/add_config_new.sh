#!/bin/bash

path_wpa="/etc/wpa_supplicant/wpa_supplicant.conf"

path_ip="../data/wlan_ip"
file="wlan_ip"

#path_ip="$path_ip$file
sudo echo $path_ip


>$path_wpa
sudo echo "country=DE" >>  $path_wpa
sudo echo "ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev" >>  $path_wpa
sudo echo "update_config=1" >>  $path_wpa
sudo echo "" >> $path_wpa
sudo echo "network={" >> $path_wpa
sudo echo "    ssid=\"$1\"" >> $path_wpa
sudo echo "    scan_ssid=1" >> $path_wpa
sudo echo "    key_mgmt=WPA-EAP WPA-PSK NONE" >> $path_wpa
sudo echo "    pairwise=CCMP TKIP" >> $path_wpa
sudo echo "    psk=\"$2\"" >> $path_wpa
sudo echo "}" >> $path_wpa

# Catch all example that allows more or less all configuration modes
#network={
#       ssid="example"
#       scan_ssid=1
#       key_mgmt=WPA-EAP WPA-PSK NONE
#       pairwise=CCMP TKIP
#       group=CCMP TKIP WEP104 WEP40
#       psk="very secret passphrase"
#}


sudo ifdown wlan0
sudo ifup wlan0

#FILE=$5
VALUE=$(ip a | grep "inet" | grep -v "inet6" | grep -v "eth" | grep -v "host lo" | awk '{print $2}')
echo ${VALUE%/*}
>$path_ip

sudo sh -c "echo -n '${VALUE%/*}' >> $path_ip"

