/**
 * \file   
 * \author Philipp Johannes 
 * \date   Oktober 2017
 * \brief  Headerfile für ADC Ansteuerung
 */

#ifndef GRILLL_PROJEKT_ADS1220_H
#define GRILLL_PROJEKT_ADS1220_H

#include <stdint.h>
#include <pthread.h>


//CMD
#define SPI_MASTER_DUMMY        0x00
#define RESET                   0x06           
#define START                   0x08 
#define WREG                    0x40
#define RREG                    0x20
#define CONFIG_REG0_ADDRESS     (0x00<<2)
#define CONFIG_REG1_ADDRESS     (0x01<<2)
#define CONFIG_REG2_ADDRESS     (0x02<<2)
#define CONFIG_REG3_ADDRESS     (0x03<<2)

//SAMPLE Register
#define REG_CONFIG_DR_20SPS     0x00
#define REG_CONFIG_DR_45SPS     0x20
#define REG_CONFIG_DR_90SPS     0x40
#define REG_CONFIG_DR_175SPS    0x60
#define REG_CONFIG_DR_330SPS    0x80
#define REG_CONFIG_DR_600SPS    0xA0
#define REG_CONFIG_DR_1000SPS   0xC0
#define REG_CONFIG_DR_MASK      0xE0

//Register
#define NUM_REGS_1  0x00
#define NUM_REGS_2  0x01
#define NUM_REGS_3  0x02
#define NUM_REGS_4  0x03


//MUX
#define MUX_0_1     0x00
#define MUX_0_2     0x10
#define MUX_0_3     0x20
#define MUX_1_2     0x30
#define MUX_1_3     0x40
#define MUX_2_3     0x50
#define MUX_1_0     0x60
#define MUX_3_2     0x70
#define MUX_0_G     0x80
#define MUX_1_G     0x90
#define MUX_2_G     0xa0
#define MUX_3_G     0xb0
#define MUX_EX_VREF 0xc0
#define MUX_AVDD    0xd0
#define MUX_DIV2    0xe0

//SAMPLE
#define DR_20SPS    20
#define DR_45SPS    45
#define DR_90SPS    90
#define DR_175SPS   175
#define DR_330SPS   330
#define DR_600SPS   600
#define DR_1000SPS  1000

//GAIN Register
#define REG_CONFIG_PGA_GAIN_1       0x00
#define REG_CONFIG_PGA_GAIN_2       0x02
#define REG_CONFIG_PGA_GAIN_4       0x04
#define REG_CONFIG_PGA_GAIN_8       0x06
#define REG_CONFIG_PGA_GAIN_16      0x08
#define REG_CONFIG_PGA_GAIN_32      0x0A
#define REG_CONFIG_PGA_GAIN_64      0x0C
#define REG_CONFIG_PGA_GAIN_128     0x0E
#define REG_CONFIG_PGA_GAIN_MASK    0x0E

//GAIN
#define PGA_GAIN_1      1
#define PGA_GAIN_2      2
#define PGA_GAIN_4      4
#define PGA_GAIN_8      8
#define PGA_GAIN_16     16
#define PGA_GAIN_32     32
#define PGA_GAIN_64     64
#define PGA_GAIN_128    128


#define PGA     1                // Programmable Gain = 1
#define VREF    2.048            // Internal reference 2.048V
#define VFSR    VREF/PGA
#define FSR     0x7fffff

#define MAX_LOAD    12800
#define RESOLUTION  7
#define MIN_LOAD    12200

#define CHARGING 13400
#define LOAD_100 12800
#define LOAD_66 12600
#define LOAD_33 12400
#define LOAD_0  12200

//! ADC Klasse
/*!
    Ansteuerung des ADC Chips
*/
class ADS1220
{
public:
    //! Constructor
    /*!
    *@param channel SPI Kanal
    *@param cs_pin CS Pin
    *@param dryd_pin DRYD Pin
    */
    ADS1220(uint8_t channel, uint8_t cs_pin, uint8_t dryd_pin, pthread_mutex_t *spi_lock);
    //! Konfiguration einstellen
    void        init();
    //! Spannungswert auslesen
    /*!
    *@return Spannungswert in mV
    */
    uint32_t    get_voltage();
    //! Eingangskanal ändern
    /*!
    *@param adc_ch ADC Kanal
    */
    void        set_adc_channel(uint8_t adc_ch);

    void channel_voltage(uint8_t adc_ch, float voltage);


private:
    uint8_t channel;    ///< SPI Channel
    uint8_t cs_pin;     ///< CS Pin
    uint8_t dryd_pin;   ///< DRYD Pin
    uint8_t sel_ch;
    pthread_mutex_t *spi_lock;
    float ch_voltage[4];

    //! ADC-Wert auslesen
    /*!
    *@return ADC-Wert
    */
    uint32_t raw_voltage();
    //! Register auslesen
    /*!
    *@param address Register Adresse
    *@param reg_num Register Nummer
    *@param value Wert
    */
    void get_register(uint8_t address, uint8_t reg_num, uint8_t* value);
    //! Register schreiben
    /*!
    *@param address Register Adresse
    *@param reg_num Register Nummer
    *@param value Wert
    */
    void set_register(uint8_t address, uint8_t reg_num, uint8_t* value);

    void write_data(char* data, char* out, uint8_t len);
};

#endif //GRILLL_PROJEKT_ADS1220_H
