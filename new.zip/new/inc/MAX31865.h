/**
 * \file   
 * \author Philipp Johannes 
 * \date   Februar 2017
 * \brief  Headerfile für die RTD Sensorik
 */

#ifndef GRILLL_PROJEKT_MAX31865_H
#define GRILLL_PROJEKT_MAX31865_H

#include <stdint.h>

//CMD READ
#define READ_CONFIG 0x00
#define READ_RTD_MSB 0x01
#define READ_HIGH_FAULT_THRESHOLD 0x03
#define READ_LOW_FAULT_THRESHOLD 0x05
#define READ_FAULT_STATUS 0x07
//CMD WRITE
#define WRITE_CONFIG 0x80
#define WRITE_HIGH_FAULT_THRESHOLD 0x83
#define WRITE_LOW_FAULT_THRESHOLD 0x85

//CONFIG
#define MAX31865_FAULT_HIGH_THRESHOLD   (1<<7)
#define MAX31865_FAULT_LOW_THRESHOLD    (1<<6)
#define MAX31865_FAULT_REFIN            (1<<5)
#define MAX31865_FAULT_REFIN_FORCE      (1<<4)
#define MAX31865_FAULT_RTDIN_FORCE      (1<<3)
#define MAX31865_FAULT_VOLTAGE          (1<<2)

#define MAX31865_FAULT_DETECTION_NONE      ( 0x00 << 2 )
#define MAX31865_FAULT_DETECTION_AUTO      ( 0x01 << 2 )
#define MAX31865_FAULT_DETECTION_MANUAL_1  ( 0x02 << 2 )
#define MAX31865_FAULT_DETECTION_MANUAL_2  ( 0x03 << 2 )

#define MAX31865_VBIAS_ON           1
#define MAX31865_VBIAS_OFF          0
#define MAX31865_CONVERSION_AUTO    1
#define MAX31865_CONVERSION_OFF     0
#define MAX31865_ONE_SHOT_ON        1
#define MAX31865_ONE_SHOT_OFF       0
#define MAX31865_THREE_WIRE         1
#define MAX31865_TWO_WIRE           0
#define MAX31865_FILTER_50HZ        1
#define MAX31865_FILTER_60HZ        0
#define MAX31865_FAULT_CYCLE_ON     3
#define MAX31865_FAULT_CYCLE_OFF    0
//ERROR
#define ERROR_HIGH_TRESHOLD         0x80
#define ERROR_LOW_TRESHOLD          0x40
#define ERROR_REFIN_GREATER_VBIAS   0x20
#define ERROR_REFIN_LESS_VBIAS      0x10
#define ERROR_RTDIN_LESS_VBIAS      0x08
#define ERROR_OVER_UNDER_VOLTAGE    0x04

//REF RTD
#define RTD_RREF_PT100         400 /* Ohm */
#define RTD_RREF_PT1000       4000 /* Ohm */
//RTD
#define RTD_RESISTANCE_PT100   100 /* Ohm */
#define RTD_RESISTANCE_PT1000 1000 /* Ohm */
#define RTD_PT100 100
#define RTD_PT1000 1000
//ADC RESOLUTION
#define RTD_ADC_RESOLUTION  0x10000

#define KABLE_RESISTANCE 1
//CONSTANTS
#define RTD_A_ITS90         3.9080e-3
#define RTD_B_ITS90         -5.870e-7

//CONFIG Type
//!\struct CONFIG_MAX
typedef struct {
    bool vbias;
    bool conversion_mode;
    bool one_shot;
    bool three_wire;
    bool fault_cycle;
    bool fault_clear;
    bool filter;
    uint16_t high_threshold;
    uint16_t low_threshold;
}CONFIG_MAX;

//! RTD Klasse
/*!
    Ansteuerung der RTD Sensorik
*/
class MAX31865
{
public:
    //! Konstruktor
    /*!
    *@param RTD RTD Typ
    *@param channel SPI Channel
    */
    MAX31865(uint8_t RTD, uint8_t channel);
    //! Konfiguration
    /*!
    *@param new_config Konfigurationsdaten
    */
    void configure(CONFIG_MAX new_config);
    //! Alle Werte auslesen
    /*!
    *return Status des RTD-Sensors
    */
    uint8_t read_all();
    //! Status auslesen
    /*!
    *return Status des RTD-Sensors
    */
    uint8_t status();
    //! Error rücksetzen   
    void clear_fault();
    //! Temperatur auslesen
    /*!
    *return Temperatur in °C
    */    
    double get_temp();
    //! Widerstand auslesen
    /*!
    *return Widerstand in OHM
    */ 
    double get_resistance();
private:
    uint8_t channel;                        ///< SPI Channel
    uint8_t RTD_type;                       ///< RTD Typ
    CONFIG_MAX config_control;              ///< Konfigurationsdaten
    uint16_t config_high_fault_threshold;   ///< Oberer Fehlergrenzwert
    uint16_t config_low_fault_threshold;    ///< Unterer Fehlergrenzwert 

    uint8_t  config;                        ///< Gespeicherte Konfiguration (Register)
    uint16_t resistance;                    ///< Widerstand
    uint8_t  status_rtd;                    ///< Status

    //! Konfigurationsdaten setzen
    void  set_config();
    //! Widerstands Regiserwert auslesen
    void read_resistance();
    //! Datenübertragung zum Chip
    /*!
    *@param data Daten
    *@param len Datenlänge
    */
    void rw_data(uint8_t *data, uint8_t len);
};

#endif //GRILLL_PROJEKT_MAX31865_H
