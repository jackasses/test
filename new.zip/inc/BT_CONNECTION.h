#ifndef BT_CONNECTION_H
#define BT_CONNECTION_H


#include <fstream>
#include <stdint.h>
#include <stdio.h>
#include "data.h"

#define DATA_LEN 80
#define MAX_INPUT_LEN 18
#define ON  1
#define OFF 0
#define DEATHTIME 4000

typedef union 
{
	struct{
		uint8_t ssid:1;    	//1
		uint8_t pwd:1;		//2
		uint8_t sec:1;				//3
		uint8_t ssid_last_cmd:1;			//4
		uint8_t pwd_last_cmd:1;		//5
		uint8_t motor_stck:1;		//6
		uint8_t fan_r_error:1;		//7
		uint8_t fan_l_error:1;		//8
	}bit_state;
	uint8_t state;
}WLAN_STATE;

class BT_CONNECTION
{
public:
	BT_CONNECTION();
	~BT_CONNECTION();

	uint8_t setup(char *fd_device, uint8_t speed);
	void send_frame(FRAME *data);
	//Daten von BT
	void read_data();
	//Protokoll Statemachine
	void check_data();
	FRAME* get_data();
	void device_alive();
	uint8_t get_device_state();
	uint8_t get_wlan_state();
	uint32_t get_IP();
	void set_ip_state(uint8_t ip_state);
	char*  get_wlan_ssid();
	char*  get_wlan_pw();
	uint8_t new_login();
	uint8_t get_login_state();
	void bt_startup();
	void bt_shutdown();
	void mc_shutdown();

private:
	int fd;
	char data_copy[DATA_LEN];//test
	char data_in[DATA_LEN];
	uint8_t data_in_len;
	uint8_t data_raw;
	char data_out[DATA_LEN];
	uint8_t data_out_len;
	uint8_t crc;
	uint8_t last_cmd;
	//DATEN für weiterverarbeitung
	uint8_t connection_state;
	uint8_t wlan_info_len;
	WLANSTATE wlan_info_state;
	WLAN login;
	FRAME bt_data;

	//test PKG
	uint8_t pkg_count;
	uint8_t pkg_num;
	char pkg[68];
	uint8_t pkg_num_last;
	uint8_t pkg_init;
	uint8_t pkg_len;
	uint8_t pkg_len_null; //löschen der leeren oder unbrauchbaren Zeichen
	uint8_t pkg_get_count;
	WLAN_STATE state;
	uint8_t new_login_state;

	uint8_t device_active;
	uint32_t last_active;

	uint8_t data_read_done;

	uint8_t get_cmd(uint8_t cmd_in);
	void set_data();
	void package_worker(uint8_t wlan_cmd);
	void show_data();
	//Daten an BT
	void send_data(char *new_data, char len);
	void set_device_state(uint8_t active);
	void set_wlan_configuration();

	void serial_send(char data);

};


#endif