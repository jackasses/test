/**
 * \file   
 * \author Philipp Johannes 
 * \date   Februar 2017
 * \brief  Headerfile für IO
 */

#ifndef GRILLL_PROJEKT_IOCONTROLL_H
#define GRILLL_PROJEKT_IOCONTROLL_H

#include <stdint.h>

//GPIO
#define PIN_LED_GRN     1
#define PIN_LED_RED     2
#define PIN_MUX_A       5
#define PIN_MUX_B       6
#define PIN_MUX_C       13
#define PIN_CS_EN       25
#define PIN_DRDY        26
#define PIN_DRDY_EN     19
#define PIN_FAN_1_PWM   17
#define PIN_FAN_2_PWM   18
#define PIN_FAN_1_TACHO 27
#define PIN_FAN_2_TACHO 22
#define PIN_FAN_SUPLY   4
#define FAN_PWM_RANGE   255
//FAN
#define FAN_1 1
#define FAN_2 2

//! GPIO Klasse
/*!
    Ansteuerung der GPIO und Lüfter
*/
class IOcontroll
{
public:
    //! Constructor
    /*!
        Initialisierung der GPIO
    */
    IOcontroll();
    //! Lüfter Einstellung setzen
    /*!
    *@param fan Lüfterauswahl
    *@param value  Wert  
    */
    void set_fan_value(uint8_t fan, uint8_t value);
    //! Lüfter Status abfragen
    /*!
    *@return Lüfterstatus
    */
    uint8_t get_fan_state();
    //! CS/DRYD Mux initialisieren
    void config_mux();
    //! CS/DRYD Mux setzen
    /*!
    *@param channel Kanal
    */
    void set_mux(uint8_t channel);
    //! rote LED setzen
    /*!
    *@param value Wert
    */
    void set_led_red(uint8_t value);
    //! grüne LED setzen
    /*!
    *@param value Wert
    */
    void set_led_grn(uint8_t value);

    void write_gpio(int gpio, int value);

    int read_gpio(int gpio);
    
    void set_mode(int gpio, int mode);

private:
    uint8_t fan1_value; ///< Lüfter1 Wert
    uint8_t fan2_value; ///< Lüfter2 Wert
    uint8_t fan_state;  ///< Lüfterzustand (an/aus)
    uint8_t fifo1;      ///< Zwischenpuffer Lüfterwert von Lüfter1
    uint8_t fifo2;      ///< Zwischenpuffer Lüfterwert von Lüfter1

    void error_check(int gpio, int ret_val);
};

#endif //GRILLL_PROJEKT_IOCONTROLL_H
