/*// extern char* script_path[];	

// extern char* post_id[]; 		
// extern char* post_grill_id[]; 	
// extern char* post_data[]; 		
// extern char* boot_wlan[]; 		
// extern char* add_config[]; 		
// extern char* ping_server[]; 	
// extern char* time_log[]; 		
// extern char* shutdown_pi[]; 	

// extern char* file_path[]; 

// extern char* grill_id_path[]; 	
// extern char* session_id_path[]; 
// extern char* session_data_path[];
// extern char* access_token_path[];
// extern char* wlan_ip_path[]; 	
// extern char* login_path[]; 		
// extern char* log_data_path[]; 	
// extern char* wpa_config_path[]; 
// extern char* name_path[]; 

// extern char* queue_path[]; 

// extern char* s2c_path[]; 		
// extern char* c2s_path[]; 		
// extern char* token_path[]; 		
// extern char* con_state_path[];

#include <string>
#include <string.h>

extern std::string script_path;	

extern std::string post_id; 		
extern std::string post_grill_id; 	
extern std::string post_data; 		
extern std::string boot_wlan; 		
extern std::string add_config; 		
extern std::string ping_server; 	
extern std::string time_log; 		
extern std::string shutdown_pi; 	

extern std::string file_path; 

extern std::string grill_id_path; 	
extern std::string session_id_path; 
extern std::string session_data_path;
extern std::string access_token_path;
extern std::string wlan_ip_path; 	
extern std::string login_path; 		
extern std::string log_data_path; 	
extern std::string wpa_config_path; 
extern std::string name_path; 

extern std::string queue_path; 

extern std::string s2c_path; 		
extern std::string c2s_path; 		
extern std::string token_path; 		
extern std::string con_state_path;*/