

#ifndef GRILLL_PROJEKT_L6470_H
#define GRILLL_PROJEKT_L6470_H

#include <stdint.h>
#include <pthread.h>

// constant definitions for overcurrent thresholds. Write these values to
//  register dSPIN_OCD_TH to set the level at which an overcurrent even occurs.
#define OCD_TH_375mA  0x00
#define OCD_TH_750mA  0x01
#define OCD_TH_1125mA 0x02
#define OCD_TH_1500mA 0x03
#define OCD_TH_1875mA 0x04
#define OCD_TH_2250mA 0x05
#define OCD_TH_2625mA 0x06
#define OCD_TH_3000mA 0x07
#define OCD_TH_3375mA 0x08
#define OCD_TH_3750mA 0x09
#define OCD_TH_4125mA 0x0A
#define OCD_TH_4500mA 0x0B
#define OCD_TH_4875mA 0x0C
#define OCD_TH_5250mA 0x0D
#define OCD_TH_5625mA 0x0E
#define OCD_TH_6000mA 0x0F

// STEP_MODE option values.
// First comes the "microsteps per step" options...
#define STEP_MODE_STEP_SEL 0x07  // Mask for these bits only.
//#define STEP_SEL_1     0x00
//#define STEP_SEL_1_2   0x01
//#define STEP_SEL_1_4   0x02
#define STEP_SEL_1_8   0x03
//#define STEP_SEL_1_16  0x04
//#define STEP_SEL_1_32  0x05
//#define STEP_SEL_1_64  0x06
//#define STEP_SEL_1_128 0x07

#ifdef STEP_SEL_1
#define STEP_SEL 0x00
#define STEP_MULTIPLIER 1 
#elif STEP_SEL_1_2
#define STEP_SEL 0x01
#define STEP_MULTIPLIER 2
#elif STEP_SEL_1_4
#define STEP_SEL 0x02
#define STEP_MULTIPLIER 4
#elif STEP_SEL_1_8
#define STEP_SEL 0x03
#define STEP_MULTIPLIER 8
#elif STEP_SEL_1_16
#define STEP_SEL 0x04
#define STEP_MULTIPLIER 16
#elif STEP_SEL_1_32
#define STEP_SEL 0x05
#define STEP_MULTIPLIER 32
#elif STEP_SEL_1_64
#define STEP_SEL 0x06
#define STEP_MULTIPLIER 64
#elif STEP_SEL_1_128
#define STEP_SEL 0x07
#define STEP_MULTIPLIER 128
#endif

// ...next, define the SYNC_EN bit. When set, the BUSYN pin will instead
//  output a clock related to the full-step frequency as defined by the
//  SYNC_SEL bits below.
#define STEP_MODE_SYNC_EN    0x80  // Mask for this bit
#define SYNC_EN 0x80

// ...last, define the SYNC_SEL modes. The clock output is defined by
//  the full-step frequency and the value in these bits- see the datasheet
//  for a matrix describing that relationship (page 46).
#define STEP_MODE_SYNC_SEL 0x70
#define SYNC_SEL_1_2 0x00
#define SYNC_SEL_1   0x10
#define SYNC_SEL_2   0x20
#define SYNC_SEL_4   0x30
#define SYNC_SEL_8   0x40
#define SYNC_SEL_16  0x50
#define SYNC_SEL_32  0x60
#define SYNC_SEL_64  0x70

// Configure the functionality of the external switch input
#define CONFIG_SW_HARD_STOP            0x0000
#define CONFIG_SW_USER                 0x0010

// Configure the motor voltage compensation mode (see page 34 of datasheet)
#define CONFIG_VS_COMP_DISABLE         0x0000  // Disable motor voltage compensation.
#define CONFIG_VS_COMP_ENABLE          0x0020  // Enable motor voltage compensation.

// Configure overcurrent detection event handling
#define CONFIG_OC_SD_DISABLE           0x0000  // Bridges do NOT shutdown on OC detect
#define CONFIG_OC_SD_ENABLE            0x0080  // Bridges shutdown on OC detect

// Configure the slew rate of the power bridge output
#define CONFIG_SR_180V_us              0x0000  // 180V/us
#define CONFIG_SR_290V_us              0x0200  // 290V/us
#define CONFIG_SR_530V_us              0x0300  // 530V/us


// Integer divisors for PWM sinewave generation
//  See page 32 of the datasheet for more information on this.
#define CONFIG_PWM_MUL_0_625           (0x00)<<10
#define CONFIG_PWM_MUL_0_75            (0x01)<<10
#define CONFIG_PWM_MUL_0_875           (0x02)<<10
#define CONFIG_PWM_MUL_1               (0x03)<<10
#define CONFIG_PWM_MUL_1_25            (0x04)<<10
#define CONFIG_PWM_MUL_1_5             (0x05)<<10
#define CONFIG_PWM_MUL_1_75            (0x06)<<10
#define CONFIG_PWM_MUL_2               (0x07)<<10

// Multiplier for the PWM sinewave frequency
#define CONFIG_PWM_DIV_1               (0x00)<<13
#define CONFIG_PWM_DIV_2               (0x01)<<13
#define CONFIG_PWM_DIV_3               (0x02)<<13
#define CONFIG_PWM_DIV_4               (0x03)<<13
#define CONFIG_PWM_DIV_5               (0x04)<<13
#define CONFIG_PWM_DIV_6               (0x05)<<13
#define CONFIG_PWM_DIV_7               (0x06)<<13

// Oscillator options.
// The dSPIN needs to know what the clock frequency is because it uses that for some
//  calculations during operation.
#define CONFIG_OSC_SEL                 0x000F // Mask for this bit field.
#define CONFIG_INT_16MHZ               0x0000 // Internal 16MHz, no output
#define CONFIG_INT_16MHZ_OSCOUT_2MHZ   0x0008 // Default; internal 16MHz, 2MHz output
#define CONFIG_INT_16MHZ_OSCOUT_4MHZ   0x0009 // Internal 16MHz, 4MHz output
#define CONFIG_INT_16MHZ_OSCOUT_8MHZ   0x000A // Internal 16MHz, 8MHz output
#define CONFIG_INT_16MHZ_OSCOUT_16MHZ  0x000B // Internal 16MHz, 16MHz output
#define CONFIG_EXT_8MHZ_XTAL_DRIVE     0x0004 // External 8MHz crystal
#define CONFIG_EXT_16MHZ_XTAL_DRIVE    0x0005 // External 16MHz crystal
#define CONFIG_EXT_24MHZ_XTAL_DRIVE    0x0006 // External 24MHz crystal
#define CONFIG_EXT_32MHZ_XTAL_DRIVE    0x0007 // External 32MHz crystal
#define CONFIG_EXT_8MHZ_OSCOUT_INVERT  0x000C // External 8MHz crystal, output inverted
#define CONFIG_EXT_16MHZ_OSCOUT_INVERT 0x000D // External 16MHz crystal, output inverted
#define CONFIG_EXT_24MHZ_OSCOUT_INVERT 0x000E // External 24MHz crystal, output inverted
#define CONFIG_EXT_32MHZ_OSCOUT_INVERT 0x000F // External 32MHz crystal, output inverted

// Register address redefines.
//  See the dSPIN_Param_Handler() function for more info about these.
#define ABS_POS     0x1601     //REG_SIZE_ABS_POS     22
#define EL_POS      0x0902     //REG_SIZE_EL_POS      9
#define MARK        0x1603     //REG_SIZE_MARK        22
#define SPEED       0x1404     //REG_SIZE_SPEED       20
#define ACC         0x0C05     //REG_SIZE_ACC         12
#define DEC         0x0C06     //REG_SIZE_DEC         12
#define MAX_SPEED   0x0A07       //REG_SIZE_MAX_SPEED   10
#define MIN_SPEED   0x0C08       //REG_SIZE_MIN_SPEED   12
#define FS_SPD      0x0A15       //REG_SIZE_FS_SPD      10
#define KVAL_HOLD   0x0809       //REG_SIZE_KVAL_HOLD   8
#define KVAL_RUN    0x080A       //REG_SIZE_KVAL_RUN    8
#define KVAL_ACC    0x080B       //REG_SIZE_KVAL_ACC    8
#define KVAL_DEC    0x080C       //REG_SIZE_KVAL_DEC    8
#define INT_SPD     0x0E0D       //REG_SIZE_INT_SPD     14
#define ST_SLP      0x080E       //REG_SIZE_ST_SLP      8
#define FN_SLP_ACC  0x080F       //REG_SIZE_FN_SLP_ACC  8
#define FN_SLP_DEC  0x0810       //REG_SIZE_FN_SLP_DEC  8
#define K_THERM     0x0411       //REG_SIZE_K_THERM     4
#define ADC_OUT     0x0012       //REG_SIZE_ADC_OUT     0
#define OCD_TH      0x0413       //REG_SIZE_OCD_TH      4
#define STALL_TH    0x0714       //REG_SIZE_STALL_TH    7
#define STEP_MODE   0x0816       //REG_SIZE_STEP_MODE   8
#define ALARM_EN    0x0817       //REG_SIZE_ALARM_EN    8
#define CONFIG      0x1018       //REG_SIZE_CONFIG      16
#define STATUS      0x1019       //REG_SIZE_STATUS      16

/*#define REG_SIZE_22 22
#define REG_SIZE_20 20
#define REG_SIZE_16 16
#define REG_SIZE_14 14
#define REG_SIZE_12 12
#define REG_SIZE_10 10
#define REG_SIZE_8 8
#define REG_SIZE_7 7
#define REG_SIZE_4 4
#define REG_SIZE_0 0*/


//bits per Register
/*
#define REG_SIZE_ABS_POS     22
#define REG_SIZE_EL_POS      9
#define REG_SIZE_MARK        22
#define REG_SIZE_SPEED       20
#define REG_SIZE_ACC         12
#define REG_SIZE_DEC         12
#define REG_SIZE_MAX_SPEED   10
#define REG_SIZE_MIN_SPEED   12
#define REG_SIZE_FS_SPD      10
#define REG_SIZE_KVAL_HOLD   8
#define REG_SIZE_KVAL_RUN    8
#define REG_SIZE_KVAL_ACC    8
#define REG_SIZE_KVAL_DEC    8
#define REG_SIZE_INT_SPD     14
#define REG_SIZE_ST_SLP      8
#define REG_SIZE_FN_SLP_ACC  8
#define REG_SIZE_FN_SLP_DEC  8
#define REG_SIZE_K_THERM     4
#define REG_SIZE_ADC_OUT     0
#define REG_SIZE_OCD_TH      4
#define REG_SIZE_STALL_TH    7
#define REG_SIZE_STEP_MODE   8
#define REG_SIZE_ALARM_EN    8
#define REG_SIZE_CONFIG      16
#define REG_SIZE_STATUS      16*/

//dSPIN commands
#define NOP             0x00
#define SET_PARAMETER   0x00
#define GET_PARAMETER   0x20
#define RUN             0x50
#define STEP_CLOCK      0x58
#define MOVE            0x40
#define GOTO            0x60
#define GOTO_DIR        0x68
#define GO_UNTIL        0x82
#define RELEASE_SW      0x92
#define GO_HOME         0x70
#define GO_MARK         0x78
#define RESET_POS       0xD8
#define RESET_DEVICE    0xC0
#define SOFT_STOP       0xB0
#define HARD_STOP       0xB8
#define SOFT_HIZ        0xA0
#define HARD_HIZ        0xA8
#define GET_STATUS      0xD0

//Status
#define SCK_MOD_STATE       0x8000
#define STEP_LOSS_B_STATE   0x4000
#define STEP_LOSS_A_STATE   0x2000
#define OCD_STATE           0x1000
#define TH_SD_STATE         0x0800
#define TH_WRN_STATE        0x0400
#define UVLO_STATE          0x0200
#define WRONG_CMD_STATE     0x0100
#define NOTPERF_CMD_STATE   0x0080
#define MOT_STATUS_STATE    0x0060
#define DIR_STATE           0x0010
#define SW_EVN_STATE        0x0008
#define SW_F_STATE          0x0004
#define BUSY_STATE          0x0002
#define HIZ_STATE           0x0001





#define BOOTUP_CONFIG 0x2E88

#define PIN_MOTOR_FLAG      20
#define PIN_MOTOR_BSY       16
#define PIN_MOTOR_STCK      12
#define PIN_MOTOR_STBY_RST  21
#define PIN_LIMIT_SW_TOP    23
#define PIN_LIMIT_SW_BOTTOM 24

#define LIMIT_TOP       1
#define LIMIT_BOTTOM    2
//Ausgerechnete Runden bei 280mm
#define MAX_REVOLUTIONS 100
#define STEPS_PER_REV   200
#define ROTATE_DOWN 0
#define ROTATE_UP   1

class L6470{
public:
    L6470(uint8_t channel, pthread_mutex_t *spi_lock);
    uint8_t init(uint8_t current, uint16_t speed, uint8_t stepmode);
    uint8_t init_new();
    void set_parameter(uint16_t parameter, uint32_t value);
    uint32_t get_parameter(uint16_t parameter);
    void set_run();
    void set_auto_run(uint8_t dir, uint8_t limit);
    void run(uint8_t, uint32_t);
    void move(uint32_t steps, uint8_t dir);
    void move_to(uint32_t steps, uint8_t limit);
    void move_to_dir(uint32_t steps, uint8_t dir);
    void move_round(uint8_t limit);
    void goto_pos(uint32_t position);
    void goto_dir(uint32_t pos, uint8_t dir);
    void go_home();
    void reset_pos();
    void softstop();
    void hardstop();
    void hardhiz();
    uint8_t limit();
    uint16_t get_status();
    void set_position(uint8_t position);
    uint8_t get_position();
    uint8_t get_calibration();
    //test
    void set_calibration();
    //void set_positionActual(uint8_t position);

private:
    uint8_t channel;
    uint8_t speed;
    uint8_t position_actual;
    uint8_t position_target;
    uint8_t calibration;
    pthread_mutex_t *spi_lock;
    int handle;

    uint32_t test;

    uint32_t reg_func(uint16_t parameter, uint32_t value);
    uint32_t calc_speed(uint32_t speed);
    uint32_t calc_max_speed(uint32_t speed);
    uint32_t calc_min_speed(uint32_t speed);
    void write_data(uint8_t* data, uint8_t len);
    void read_data(uint8_t* data, uint8_t len);

};

#endif //GRILLL_PROJEKT_L6470_H
