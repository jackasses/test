/**
 * \file   
 * \author Philipp Johannes 
 * \date   Februar 2017
 * \brief  Codefile für ADC Ansteuerung
 */

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../inc/ADS1220.h"
#include "pigpio.h"

//#define DEBUG


ADS1220::ADS1220(uint8_t channel, uint8_t cs_pin, uint8_t dryd_pin,  pthread_mutex_t *spi_lock)
{
    this->channel = channel;
    this->cs_pin = cs_pin;
    this->dryd_pin = dryd_pin;
    this->spi_lock  = spi_lock;
}

void ADS1220::init()
{
    char data[3];

    while(1)
    {
    #ifdef DEBUG
        printf("Write Reg\n");
    #endif
        if((pthread_mutex_trylock(this->spi_lock)) == 0)
        {

        data[0] = WREG | CONFIG_REG0_ADDRESS | NUM_REGS_2;
        data[1] = MUX_0_G;             //REG 0
        data[2] = REG_CONFIG_DR_90SPS; //REG 1

        write_data(data,0, 3);
        gpioDelay(10);

    #ifdef DEBUG
        printf("Read Reg\n");
    #endif

        data[0] = RREG | CONFIG_REG0_ADDRESS | NUM_REGS_2;
        data[1] = SPI_MASTER_DUMMY;
        data[2] = SPI_MASTER_DUMMY;

        write_data(data,0, 3);

            pthread_mutex_unlock(this->spi_lock);
        }
        else

        {
            printf("spi_lock ADS\n");
        }
    #ifdef DEBUG
        printf("reg1: %02x\n", data[1]);
        printf("reg2: %02x\n", data[2]);
    #endif

        if(data[1] == MUX_0_G)
        {
            if(data[2] == REG_CONFIG_DR_90SPS)
            {
                printf("data: %02x %02x\n", data[1], data[2]);
                break;
            }
        }
    }
}

void ADS1220::set_adc_channel(uint8_t adc_ch)
{
    char data[2];

    switch(adc_ch)
    {
        case 0:  data[1] = MUX_0_G;
                sel_ch = 0;
            break;
        case 1:  data[1] = MUX_1_G;
                sel_ch = 1;
            break;
        case 2:  data[1] = MUX_2_G;
                sel_ch = 2;
            break;
        case 3:  data[1] = MUX_3_G;
                sel_ch = 3;
            break;
    }
    data[0] = WREG | CONFIG_REG0_ADDRESS | NUM_REGS_1;

    if((pthread_mutex_trylock(this->spi_lock)) == 0)
    {
        write_data(data,0, 2);
        gpioDelay(10);
        pthread_mutex_unlock(this->spi_lock);
    }
    else
    {
        printf("spi_lock ADS\n");
    }
}

void ADS1220::channel_voltage(uint8_t adc_ch, float voltage)
{
    
    ch_voltage[adc_ch] = voltage / VREF;
    printf("ch_voltage: %f\n", ch_voltage[adc_ch]);

}

uint32_t ADS1220::raw_voltage()
{
    char data[3];
    uint32_t temp;

    if((pthread_mutex_trylock(this->spi_lock)) == 0)
    {
        data[0] = START;
        write_data(data,0, 1);
        pthread_mutex_unlock(this->spi_lock);
    }
    else
    {
        printf("spi_lock ADS\n");
    }
    
    gpioDelay(100);

    while(gpioRead(this->dryd_pin));

    if((gpioRead(this->dryd_pin)) == 0)
    {
        if((pthread_mutex_trylock(this->spi_lock)) == 0)
        {        
            
        #ifdef DEBUG        
            printf("Data ready\n");
        #endif        
            data[0] = SPI_MASTER_DUMMY;
            data[1] = SPI_MASTER_DUMMY;
            data[2] = SPI_MASTER_DUMMY;

            write_data(data,0, 3);

        #ifdef DEBUG
            printf("data0: %02x\n", data[0]);
            printf("data1: %02x\n", data[1]);
            printf("data2: %02x\n", data[2]);
        #endif
            pthread_mutex_unlock(this->spi_lock);
        }
        else
        {
            printf("spi_lock ADS\n");
        }

        temp = data[0]<<16 | data[1]<<8 | data[0];
        return temp;
    }

    return 1;
}

uint32_t ADS1220::get_voltage()
{
    uint32_t voltage;
    float real_voltage;

    float voltage_mul = ch_voltage[sel_ch];

    voltage = raw_voltage();

#ifdef DEBUG
    printf("raw voltage: %06x\n", voltage);                      // Converting 3 bytes to a 24 bit int
    printf("voltage: %f\n", (float)(voltage*VFSR*1000));
    printf("real voltage: %fV\n", (float)((voltage_mul*voltage*VFSR)/FSR)); //6,6 durch multiplier
#endif
    //Berechnung beachten
    voltage = (uint32_t )((voltage_mul*(float)voltage*VFSR*1000)/FSR);     //In  mV
    return voltage;
}

void ADS1220::get_register(uint8_t address, uint8_t reg_num, uint8_t* value)
{
    char data[5];

    data[0] = RREG | address | reg_num;

    if((pthread_mutex_trylock(this->spi_lock)) == 0)
    {

/*    digitalWrite(this->cs_pin, LOW);
    wiringPiSPIDataRW(this->channel, data, reg_num+1);
    digitalWrite(this->cs_pin, HIGH);*/
    write_data(data,0, reg_num+1);

        pthread_mutex_unlock(this->spi_lock);
    }
    else
    {
        printf("spi_lock ADS\n");
    }

    memcpy(value, &(data[1]), reg_num);
}

void ADS1220::set_register(uint8_t address, uint8_t reg_num, uint8_t* value)
{
    char data[5];

    memset(data, 0, 5);
    data[0] = WREG | address | reg_num;
    memcpy(&(data[1]), value, reg_num);
 
    if((pthread_mutex_trylock(this->spi_lock)) == 0)
    {
        write_data(data,0,reg_num+1);
        pthread_mutex_unlock(this->spi_lock);
    }
    else
    {
        printf("spi_lock ADS\n");
    }
}

void ADS1220::write_data(char* data, char* out, uint8_t len)
{
    char ret[len];
    int spi_handle1 = 0;

    gpioWrite(this->cs_pin, 0);
    spiXfer(0, data, ret, len);
    gpioWrite(this->cs_pin, 1);

    memcpy(data,ret,len);
}
