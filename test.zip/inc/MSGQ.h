/**
 * \file   
 * \author Philipp Johannes 
 * \date   Juni 2017
 * \brief  Headerfile für die msg queues
 */

#ifndef MSGQ_H
#define MSGQ_H

#include <sstream>
#include <string>
#include <pthread.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "data.h"

#define MSG_QUEUE_SIZE 1

typedef struct{
	long mtype;
 	FRAME data;
}MSG_BUFFER;

typedef struct{
	long mtype;
 	INTERNAL data;
}STATE_BUFFER;

class MSGQ
{
public:
	MSGQ(){}
	~MSGQ(){}
	
	/*! Daten in den MSG Queue geben
	*@param qid Queue ID
	*@param qbuf Datenbuffer
	*@param type Queue Typ
	*@param data Daten
	*/
	void send_message(int qid, MSG_BUFFER *qbuf, long type, FRAME *data);
	/*! Daten aus dem MSG Queue lesen
	*@param qid Queue ID
	*@param qbuf Datenbuffer
	*@param type Queue Typ
	*@return Lesestatus 
	*/
	uint8_t read_message(int qid, MSG_BUFFER *qbuf, long type);
	/*! MSG Queue löschen
	*@param qid Queue ID
	*/
	void remove_queue(int qid);
	/*! MSG Queue Modus ändern
	*@param qid Queue ID
	*@param mode Modus
	*/
	void change_queue_mode(int qid, char *mode);

	void send_con_state(int qid, STATE_BUFFER *qbuf, long type, INTERNAL *data);

	uint8_t read_con_state(int qid, STATE_BUFFER *qbuf, long type);

private:
	MSG_BUFFER msg;
	STATE_BUFFER state;
};

#endif