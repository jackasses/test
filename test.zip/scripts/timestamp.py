#!/usr/bin/python

import requests
import string
import sys
import getopt
import time
from time import gmtime, strftime

#1 start / stop

def main():
	
	condition = sys.argv[1]

#	fobj_out = open("../data/start_stop_log","a")
    fobj_out = open("/home/pi/firmware/azura-firmware/new/data/start_stop_log","a")

	localseconds = time.time()
	
	localtime = time.asctime( time.localtime(time.time()) )
	print localtime
	
	if(condition == "start"):
		fobj_out.write("start: ")
	    fobj_out.write(str(localtime))
		fobj_out.write("\n")
        fobj_out.write(str(localseconds))
        fobj_out.write("\n")

	else:
		fobj_out.write("stop: ")
    	fobj_out.write(str(localtime))
        fobj_out.write("\n")
        fobj_out.write(str(localseconds))
        fobj_out.write("\n")

	fobj_out.close()

if __name__ == "__main__":
	try:
		main()
	except SystemExit, e:
		print(e)

