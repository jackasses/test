import requests
import random
import string
import json
import sys
import getopt
import oauth2 as urllib
import zipfile
from shutil import copyfile

bearer = 0

def backup():

	copyfile('../bin/main_firmware','../bin/backup/main_firmware')
	copyfile('../bin/firmware_ver','../bin/backup/firmware_ver')
	copyfile('../bin/main_fcgi','../bin/backup/main_fcgi')
	#copyfile('../bin/fcgi_ver','../bin/backup/fcgi_ver')
	print"backup done"

def copy_data():

	#path_update = "../update/test.zip"
	zip = zipfile.ZipFile(r'../update/update.zip')
	zip.extractall(r'..')
	print"update done"

def post_notify():

	url_notify = 'https://staging-api.willhelmgrill.com/api/firmwares/notify'

	data_in={
	  "name": 1
	}

	data_body = json.dumps(data_in)
	print data_body

	headers_in = {'accept': 'application/json','content-type': 'application/json', 'Authorization':bearer}
	#print headers_in

	r = requests.post(
		url_notify,
		headers = headers_in,
		data = data_body
	)
	print r
	print "            "

def main():

	path_token = "../data/access_token"

	from oauthlib.oauth2 import BackendApplicationClient

	url = 'https://staging-api.willhelmgrill.com/api/firmwares'

	access_token = ''
	fobj_in = open(path_token,"r").readlines()
  	if len(fobj_in) != 0:
		access_token = str(fobj_in[0])
	else:
		sys.exit(1)

	global bearer
	bearer = "Bearer " + access_token
	bearer = bearer.replace("\n","")
	#print "             "
	#print bearer
	#print "             "

	headers_in = {'accept':'application/json', 'Authorization':bearer}
	#print headers_in

	r = requests.get(
                url, headers=headers_in
	)
	print " "
	print r
	print "             "

	if str(r) in '<Response [200]>':
		print 'response ok'
	else:
		sys.exit(2)

	#print r.text
	#print r.content
	#print r.json()
	firmwares = json.loads(r.text)

	last_ver = '0'
	last_ver_ind = 0
	last_path = ''
	new_ver = '0'

	json_len = len(firmwares)
	i = 0
	while i<json_len:
			new_ver = firmwares[i]['version']
			if new_ver > last_ver:
						last_ver = new_ver
						last_ver_ind = i
			i = i +1
	#print "latest version:"+last_ver
	last_path =  firmwares[last_ver_ind]['path']
	print "path:" + last_path	
	print "version get"		
	print "             "

	#update download
#	r = requests.get(
 #               url_session, headers=headers_in
#	)

#	print(r.headers['content-type'])
#	fobj_out = open("../update/update.zip","w")
#	fobj_out.write(r.content)

	backup()

	copy_data()

	post_notify()

main()

# if __name__ == "__main__":
# 	try:
# 		main()
# 	except SystemExit, e:
# 		print(e)
