import requests
import random
import string
import json
import sys
import getopt
import oauth2 as urllib

#1 grill name
#2 user ID
#3 Grill Ident
#4 Firmware Version
#5 BT Version

def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
	return ''.join(random.choice(chars) for _ in range(size))

def main():
	#url_in= 'https://staging-api.willhelmgrill.com/api/grills'
 	url_in= 'https://api.willhelmgrill.com/api/grills'
	#url_in = 'http://posttestserver.com/post.php?dir=example'

	from oauthlib.oauth2 import BackendApplicationClient

	access_token = ''

	#fobj_in = open("/home/pi/grill_id","r").readlines()
	fobj_in = open("../data/access_token","r").readlines()
	print len(fobj_in)
	if(len(fobj_in) == 0) or (fobj_in[0] == "AUTH") or (fobj_in[0] == "D"):
	#	rand =  random.randint(1,100000000)
		rand = id_generator(32)
		print rand

		data_in={
		  "name": sys.argv[1],
		  "user_id": sys.argv[2],
		  #"ident": sys.argv[3],
		  "ident": rand,
		  "firmware_version": sys.argv[4],
		  "bluetooth_version":sys.argv[5]
		}

		data_body = json.dumps(data_in)
		print data_body
		
		fobj_in = open("../data/grill_id","r").readlines()

  		if len(fobj_in) != 0:
			access_token = str(fobj_in[0]) #[0:(len(fobj_in[0])-1)]
		else:
			sys.exit(1)


		print " "
#		print access_token
#		print " "
		bearer = "Bearer " + access_token
		bearer = bearer.replace("\n","")
		print "                           "
#		print bearer

		headers_in = {'accept': 'application/json','content-type': 'application/json', 'Authorization':bearer}
		print headers_in

		r = requests.post(
			url_in,
			headers = headers_in,
			data = data_body
		)

		print r
		print "            "
		#print r.text
		print r.content
		print "grill id post"
		print " 	           "

		grill_id = 0

		fobj_out = open("../data/grill_id","w")

		if str(r) in '<Response [401]>':
		  	fobj_out.write("AUTH")
		  	fobj_out.close()
			sys.exit(1)
		elif str(r) in '<Response [422]>':
		  	fobj_out.write("D")
		  	fobj_out.close()
			sys.exit(1)
		else:
			test = json.loads(r.text)
			grill_id = str(test['id'])
			print grill_id
			fobj_out.write(grill_id);
		fobj_out.close()
	else:
                if (fobj_in[0] == "AUTH") or (fobj_in[0] == "D"):
			print "error Grill ID:"
			print fobj_in[0]
                        sys.exit(1)

		grill_id = fobj_in[0]
		print "hier sollte eine grill id stehen: " + grill_id

	url_session = 'https://staging-api.willhelmgrill.com/api/grills/'+ str(grill_id) +'/sessions'

	if (len(access_token) != 0): 
		fobj_in = open("../data/access_token","r").readlines()
		access_token = str(fobj_in[0])
		bearer = "Bearer " + access_token
		bearer = bearer.replace("\n","")
		print "                           "
#	headers_in = {'accept': 'application/json','content-type': 'application/json', 'Authorization':bearer}
	else:
		sys.exit(1)

	data_session={
	  "user_id": int(sys.argv[2]),
	  "name": "Grillsession",#sys.argv[1],
	  "grill_id": grill_id
	}

	data_session_body = json.dumps(data_session)
	print data_session_body

	headers_in = {'accept': 'application/json','content-type': 'application/json', 'Authorization':bearer}
	print headers_in

	r = requests.post(
                url_session,
                headers=headers_in,
                data=data_session_body

	)
	print " "
	print r
	print "             "
	print r.text
	print "session post"
	print "             "

	fobj_out = open("../data/session_id","w")

	if str(r) in '<Response [401]>':
		#fobj_out = open("../data/session_id","w")
		fobj_out.write(" ");
	else:
		test = json.loads(r.text)
		#fobj_out = open("../data/session_id","w")
		print str(test['id'])
		fobj_out.write(str(test['id']));

	fobj_out.close()

if __name__ == "__main__":
	try:
		main()
	except SystemExit, e:
		print(e)


