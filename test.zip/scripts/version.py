import requests
import string
import json
import sys
import oauth2 as urllib
#from oauthlib.oauth2 import BackendApplicationClient

def main():

	path_token = "../data/access_token"
	path_version = "../bin/firmware_ver"
	

	url = 'https://staging-api.willhelmgrill.com/api/firmwares'

	access_token = ''

	fobj_in = open(path_token,"r").readlines()

  	if len(fobj_in) != 0:
		access_token = str(fobj_in[0])
	else:
		sys.exit(1)

	bearer = "Bearer " + access_token
	bearer = bearer.replace("\n","")

	headers_in = {'accept':'application/json', 'Authorization':bearer}
	#print headers_in

	r = requests.get(
                url, headers=headers_in
	)
	print " "
	print r
	print "             "
	#print r.text
	#print r.json()

	if str(r) in '<Response [200]>':
		print 'response ok'
	else:
		sys.exit(2)

	firmwares = json.loads(r.text)

	last_ver = '0'
	new_ver = '0'

	json_len = len(firmwares)
	i = 0
	while i<json_len:
			new_ver = firmwares[i]['version']
			if new_ver > last_ver:
						last_ver = new_ver
			i = i +1
	print "latest version:"+last_ver

	fobj_in = open(path_version,"r").readlines()
	print "data"

  	if len(fobj_in) != 0:
		version_running = str(fobj_in[0])

	print "running:" + version_running

	if version_running < last_ver:
			print "update possible"
			sys.exit(0)
	else:
			sys.exit(1)



main()

#if __name__ == "__main__":
#	try:
#		main()
#	except SystemExit, e:
#		print(e)
