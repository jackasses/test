# importing the requests library
import requests
import zipfile
 
# api-endpoint
#URL = "http://maps.googleapis.com/maps/api/geocode/json"
URL = "https://github.com/jackasses/test/blob/master/new/ADS1220.zip?raw=true"
#URL = "https://raw.githubusercontent.com/jackasses/test/master/new/build_fcgi.sh"

fobj_out = open("data_information.zip","w")
 

# sending get request and saving the response as response object
#r = requests.get(url = URL, params = PARAMS)
r = requests.get(url = URL)
 
# extracting data in json format
#data = r.json()
 
print(r.headers['content-type'])
#print(r.content)

#print r.text
fobj_out.write(r.content)

zip = zipfile.ZipFile(r'data_information.zip')
zip.extractall(r'/data')
 
# extracting latitude, longitude and formatted address 
# of the first matching location

#latitude = data['results'][0]['geometry']['location']['lat']
#longitude = data['results'][0]['geometry']['location']['lng']
#formatted_address = data['results'][0]['formatted_address']
 
# printing the output
#print("Latitude:%s\nLongitude:%s\nFormatted Address:%s"
 #     %(latitude, longitude,formatted_address))