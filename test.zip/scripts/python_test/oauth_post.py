import requests
import json
import sys
import getopt

print 'Number of arguments:', len(sys.argv), 'arguments.'
print 'Argument List:', str(sys.argv)

headers = {'content-type': 'application/json'}
#url = 'https://posttestserver.com/post.php'
url = 'http://posttestserver.com/post.php?dir=example'
data = {"eventType": "GRILL_SESSION_START", "data": 
{
  "grant_type": "password",
  "client_id": "2",
  "client_secret": "xx9TaaO25lPdajGJ0m2LRB1lasdYPGvb63U4F",
  "username": "admin@azura.de",
  "password": "123456",
  "scope": "string"
}
}
params = {'sessionKey': '93a43064a92bae539d962103', 'platformId': 1}

r = requests.post(url, params=params, data=json.dumps(data), headers=headers)

print r.json() 
