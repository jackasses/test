import requests
import json
import sys
import getopt
import oauth2 as urllib
#print 'Number of arguments:', len(sys.argv), 'arguments.'
#print 'Argument List:', str(sys.argv)

#headers_in = {'accept': 'application/json','content-type': 'application/json'}
#headers_in = {'content-type': 'application/json'}

#url_in='https://requestb.in/13ttxsr1'

user_id = 6
ident = "16"
grill_id = 6
grill_name = "test_grill"
session_id = 195

url_in= 'https://staging-api.willhelmgrill.com/api/grills'
url_session = 'https://staging-api.willhelmgrill.com/api/grills/'+ str(grill_id) +'/sessions'
url_data = 'https://staging-api.willhelmgrill.com/api/sessions/'+ str(session_id) +'/datapoints'

from oauthlib.oauth2 import BackendApplicationClient

client_id = '2'
client_secret = 'kJe9jugyL4WJTRD1iOE1jGbuuPm2I90ZRACRYlaw'


client = BackendApplicationClient(client_id=client_id)
from requests_oauthlib import OAuth2Session
oauth = OAuth2Session(client=client)
#token = oauth.fetch_token(token_url='https://staging-api.willhelmgrill.com/oauth/token', client_id=client_id, client_secret=client_secret)

#print token

#data_in = #{"eventType": "GRILL_SESSION_START", "data":
#data_in=  {
#  "name": grill_name,
#  "user_id": user_id,
#  "ident": ident,
#  "firmware_version":"1.0.0",
#  "bluetooth_version":"1.0.15"
#}
#
#
#data_body = json.dumps(data_in)
#print data_body
#
#params = {'sessionKey': '93a43064a92bae539d962103', 'platformId': 1}
#
##auth_token = str(token)
##auth_token = auth_token[46:1116]
##print "                                          "
##print auth_token
#
##bearer = "Bearer " + auth_token
#bearer = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImJmNDIyNzNkODgyZjEwYTFlNzdjMTdmZGJmZjZmZjdlNTJlMTIxYzc0YzMyOTFmMzM2MzAyYWQwNzQ4ZmViNTg5NzRhNmQwYmExNTI4NzJmIn0.eyJhdWQiOiIxIiwianRpIjoiYmY0MjI3M2Q4ODJmMTBhMWU3N2MxN2ZkYmZmNmZmN2U1MmUxMjFjNzRjMzI5MWYzMzYzMDJhZDA3NDhmZWI1ODk3NGE2ZDBiYTE1Mjg3MmYiLCJpYXQiOjE0OTYyMzIzNjAsIm5iZiI6MTQ5NjIzMjM2MCwiZXhwIjoxNTI3NzY4MzYwLCJzdWIiOiI1MSIsInNjb3BlcyI6WyJyZWFkIiwid3JpdGUiXX0.L5U68sLAKBlkLdJKCmUF0vwGgzozaxebGpeX2ep-glnAde3S2Nt2V4VbnxWFO1C6LKDbn3KwSb5qk_6JXKWJWLoFjSsekp3KrUC-glvEXFXIxiRJrz3MK4sgk4yUh-9V8G6FgPnqXNQpEMoBrM6dGdYeD8kClAFsKWYN3Qks-NdB5SAyv9JDQNL4NwNIp0R1CiLFDui-JmsnnsccfBTTpnhlvbjfmtPp9ZMyvlNvgnAvbd5k52q4Yy_oO0biFtfTZ_ejFbCqu60Te2j0cZqJk5r-6Yqe5gDMOa2GvW5rvaiIJzu0PjEp3X3_hTFJUEXQhm0nkaOiw5B01etwovBur24ZEuSwjWFAxSeGop_6SJWWkMrP8EMp-fWFDsiOQgHCcjFUMHwrwV7tv8gMPxns2ZWyh7zZzhf4eWrG-Kr3yPVkbXv5de0LaUCAAzHslHznqd7Vkx1mLaAkoBEV8FkYCGiN466U5uUb89u8G6PyCUUtFwD7ixEiZOWu38w1FhgnYm-wCuTj5c-_5VaCvh81dBE6uR41TS2ZcGDIR_UEl5KJo_POGOONbu-JjTlOPExIBX1voc_Psz7MVEuVxhuNws9p2s5TxVVzvTL-9Ok6QMXY4ANujcPy5xQDNph04ItOWXJ4Z8W4oCWluOcgkQuKHW3sDbsy1N7CYCw0DlJDzfk"
#print "                           "
##print bearer
#headers_in = {'accept': 'application/json','content-type': 'application/json', 'Authorization':bearer}
#
#r = oauth.request(
#			'POST',
#			url_in,
#			headers=headers_in,
#			data=data_body
#)
#
#print r
#print "            "
#print r.text
#print "            "
#
#data_session={
#  #"id": "1",
#  "user_id": user_id,
#  #"user_firstname": "John",
#  #"user_lastname": "Meyer",
#  "name": "Big John's BBQ Party",
#  #"code": "fe8saf7nh38f7a8s7fa8sf72",
#  "grill_id": grill_id
#  #"created_at": "yyyy-MM-dd HH:mm:ss",
#  #"updated_at": "yyyy-MM-dd HH:mm:ss"
#}
#
#data_session_body = json.dumps(data_session)
#print data_session_body
#
#
#r = oauth.request(
#		'POST',
#		url_session,
#		headers=headers_in,
#		data=data_session_body
#)
#
#print r
#print "             "
#print r.text
#print "             "
#
#data_point= {
#  "session_id": session_id,
#  "operation_mode": "auto",
#  "lift_level": "40",
#  "power_mode": "charging",
#  "batterie_level": "86",
#  "connection": "wlan",
#  "status": "0",
#  "error": "0",
#  "target_temperature": "220",
#  "temperatures": [
#    "202"
#  ],
#  "fans": [
#    "84"
#  ],
#}
#
#data_point_body = json.dumps(data_point)
#print data_point_body
#
#
#r = oauth.request(
#                'POST',
#                url_data,
#                headers=headers_in,
#                data=data_point_body
#)
#
#print r
#print "         "
#print r.text
#print "         "


